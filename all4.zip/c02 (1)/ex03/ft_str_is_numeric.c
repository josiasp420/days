/* ************************************************************************** */
 /*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jitondo <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/18 09:10:14 by jitondo           #+#    #+#             */
/*   Updated: 2024/06/18 09:10:15 by jitondo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int	ft_str_is_numeric(char *str)
{
	int n;

	n=0;

	if (str[0]=='\0'){
		return (1);
	}

	while (str[n] != '\0')
	{
		if (!str[n] >= '0' && !str[n] <= '9')
		{	write(1,&str[n],1);
			write(1,n+'0',1);
			//return (1);
		}
		n=n+1;
	}
	return(1);

}


int main()
{
        char    *str;
        str= "1111as11" ;

        printf("%d",ft_str_is_numeric(str));
}
