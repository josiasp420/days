/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jitondo <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/17 10:03:48 by jitondo           #+#    #+#             */
/*   Updated: 2024/06/18 07:12:12 by jitondo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>


int	ft_str_is_alpha(char *str)
{
	int n;

	n=0;
	while (str[n] != 0)
	{
		if (!((str[n] >= 'a' && str[n] <= 'z') ||
		 (str[n] >= 'A' && str[n] <= 'Z')))
		{
			return 0;
		}
	n++;
	}
	return 1;

}


int main()
{
	char	*str;
	str= "oimakkkk2" ;

	printf("%d",ft_str_is_alpha(str));
}
