ldapwhoami -Q | cut -c4-
