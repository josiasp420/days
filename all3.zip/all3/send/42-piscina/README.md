# Personal top 5

1. Eval Express
2. Rush 02
3. BSQ
4. [42-testimonial](https://github.com/fwuensche/42-testimonial) (a more friendly approach to 42-stupidity, includind its name)
5. [import](https://github.com/fwuensche/42-piscine-c/blob/master/import) (shell script - in the root folder - used to merge all repos into one)

# Results

## Moulinette evaluations

### Day 00

Corrected by moulinette 20 days ago 10%
ex01: OK | ex02: OK | ex03: KO | ex04: OK | ex05: OK | ex06: OK | ex07: KO | ex08: OK | ex09: OK | ex10: OK | ex11: OK

### Day 01

Corrected by moulinette 19 days ago 40%
ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: KO | ex06: OK | ex07: OK | ex08: KO | ex09: OK

### Day 02

Corrected by moulinette 19 days ago 80%
ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: Does not compile

### Day 03

Corrected by moulinette 17 days ago 0%
ex00: Does not compile | ex01: Does not compile | ex02: Does not compile | ex03: Does not compile | ex04: Does not compile | ex05: Does not compile | ex06: Does not compile | ex07: Does not compile | ex08: Does not compile | ex09: Does not compile

### Day 04

Corrected by moulinette 15 days ago 10%
ex00: OK | ex01: Does not compile | ex02: KO | ex03: KO | ex04: OK | ex05: OK | ex06: OK | ex07: OK | ex08: Does not compile | ex09: Nothing turned in

### Day 05

Corrected by moulinette 13 days ago 20%
ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: Nothing turned in | ex05: OK | ex06: OK | ex07: OK | ex08: OK | ex09: OK | ex10: OK | ex11: OK | ex12: OK | ex13: OK | ex14: OK | ex15: OK | ex16: OK | ex17: OK | ex18: KO | ex19: Nothing turned in | ex20: Nothing turned in | ex21: Nothing turned in | ex22: Nothing turned in | ex23: Nothing turned in

### Day 06

Corrected by moulinette 12 days ago 70%
ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: KO

### Day 07

Corrected by moulinette 10 days ago 60%
ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: Nothing turned in | ex07: Nothing turned in

### Day 08

Corrected by moulinette 10 days ago 0%
ex00: KO | ex01: OK | ex02: OK | ex03: OK | ex04: Nothing turned in | ex05: Nothing turned in | ex06: Nothing turned in

### Day 09

Corrected by moulinette 10 days ago 28%
ex00: OK | ex01: OK | ex02: KO | ex03: OK | ex04: OK | ex05: Does not compile | ex06: OK | ex07: OK | ex08: Nothing turned in | ex09: OK | ex10: OK | ex11: Nothing turned in | ex12: Nothing turned in | ex13: Nothing turned in | ex14: Nothing turned in | ex15: Nothing turned in | ex16: Nothing turned in | ex17: KO | ex18: Nothing turned in | ex19: Nothing turned in | ex20: KO | ex21: Nothing turned in | ex22: KO | ex23: OK

### Day 10

Corrected by moulinette 6 days ago 20%
ex00: OK | ex01: OK | ex02: KO | ex03: Does not compile | ex04: Does not compile | ex05: Does not compile | ex06: OK | ex07: Nothing turned in | ex08: Nothing turned in | ex09: Nothing turned in

### Day 11

Corrected by moulinette 5 days ago 21%
ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: KO | ex06: OK | ex07: OK | ex08: OK | ex09: OK | ex10: OK | ex11: OK | ex12: OK | ex13: Nothing turned in | ex14: Nothing turned in | ex15: Nothing turned in | ex16: Nothing turned in | ex17: Nothing turned in

### Day 12

Corrected by moulinette 4 days ago 20%
ex00: OK | ex01: KO | ex02: Nothing turned in | ex03: Nothing turned in | ex04: Nothing turned in

## Rushes

### Rush 00

CORRECTED BY EVANHEUM 14 DAYS AGO 120%
Good job keep up the great work!

### Rush 01

CORRECTED BY OFEDOROV 7 DAYS AGO 0%
Wrong grid should give error :(

### Rush 02

Loading...

## Projects

### Sastantua

Corrected by moulinette 13 days ago 0%
ex00: Norme error

### Match-N-Match

Corrected by moulinette 8 days ago 100%
ex00: OK | ex01: OK

### Eval Express

Corrected by moulinette 2 days ago 100%
ex00: OK

### BSQ

Loading...
