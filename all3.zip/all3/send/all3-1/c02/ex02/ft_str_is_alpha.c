/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jitondo <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/17 10:03:48 by jitondo           #+#    #+#             */
/*   Updated: 2024/06/17 10:03:53 by jitondo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void ft_str_is_alpha(char *str)
{
	int n;
	n=0;

	/*if (str[i] == '\0' )
	{
		return (1);
	}*/

	if (str[n] == '\0') {return (0);}	}

	while (str[n] != '\0')
	{

		if ((str[n] >= 'a') && (str[n] <= 'z') ||
		(str[n] != 'A') && (str[n] != 'Z'))

		{return (1);}

		else {return (0);}

	n++;
	}
}



int main()
{
	char *str = "oi mana";

	ft_str_is_alpha(str);
}
