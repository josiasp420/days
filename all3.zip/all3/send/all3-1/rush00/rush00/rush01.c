/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jitondo <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/15 15:51:58 by jitondo           #+#    #+#             */
/*   Updated: 2024/06/16 12:13:25 by jitondo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c);

void	multiply(int base,int vezes)
{
	int count_v=1;

	while (count_v <= vezes)
	{
		ft_putchar(base);
		count_v++;
	}
}

void	print_culumn(int column,int first,int center,int last)
{
	int count;
	count=1;

	while (count<=column)
	{
		if (count==1)
		{
			ft_putchar(first);
		}

		else if (count==column)
		{
			ft_putchar(last);
		}

		else
		{
			//repetindo o centro por pelas colunas
			multiply(center,column-2);
		}

		count++;
	}
	ft_putchar('\n');
}




void	rush(int x,int y)
{
	//int h;
	//int w;
	int count_l=1;

	while (count_l <= y)
	{
		// se for a primeira
		if (count_l==1)
		{
			print_culumn(x,'/','*','\\')
		}

		// se nao for a primeira sera a ultima linha
		else if (count_l==y)
		{
			print_culumn(x,'\\','*','/');
		}

		// se nao for a primeira nem a ultima
		else
		{
			print_culumn(x,'*,' ','*');
		}

	count_l++;
	}
}
