int	ft_mul(int a, int b)
{
	return (a * b);
}
